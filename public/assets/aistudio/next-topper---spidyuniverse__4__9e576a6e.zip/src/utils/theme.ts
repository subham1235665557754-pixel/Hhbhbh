export type ThemeId = 'midnight' | 'purple' | 'emerald' | 'crimson' | 'light';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  dotColor: string;
  bgClass: string;
  textClass: string;
  cardBg: string;
  cardBorder: string;
  accentGradient: string;
  accentText: string;
  badgeBg: string;
  heroGlow: string;
}

export const THEMES: ThemeConfig[] = [
  {
    id: 'midnight',
    name: 'Midnight Cyan',
    dotColor: '#229ED9',
    bgClass: 'bg-[#07080d]',
    textClass: 'text-white',
    cardBg: 'bg-[#0e1018]/90',
    cardBorder: 'border-white/[0.08]',
    accentGradient: 'from-blue-600 to-[#229ED9]',
    accentText: 'text-[#229ED9]',
    badgeBg: 'bg-[#229ED9]/15 text-[#229ED9] border-[#229ED9]/30',
    heroGlow: 'from-[#229ED9]/15 via-indigo-600/5 to-transparent',
  },
  {
    id: 'purple',
    name: 'Neon Royale',
    dotColor: '#a855f7',
    bgClass: 'bg-[#090714]',
    textClass: 'text-white',
    cardBg: 'bg-[#120e24]/90',
    cardBorder: 'border-purple-500/15',
    accentGradient: 'from-purple-600 to-pink-500',
    accentText: 'text-purple-400',
    badgeBg: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
    heroGlow: 'from-purple-600/20 via-pink-600/5 to-transparent',
  },
  {
    id: 'emerald',
    name: 'Emerald Matrix',
    dotColor: '#10b981',
    bgClass: 'bg-[#050e09]',
    textClass: 'text-white',
    cardBg: 'bg-[#0a1a12]/90',
    cardBorder: 'border-emerald-500/15',
    accentGradient: 'from-emerald-600 to-teal-400',
    accentText: 'text-emerald-400',
    badgeBg: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    heroGlow: 'from-emerald-500/20 via-teal-600/5 to-transparent',
  },
  {
    id: 'crimson',
    name: 'Crimson Ember',
    dotColor: '#f43f5e',
    bgClass: 'bg-[#0e0608]',
    textClass: 'text-white',
    cardBg: 'bg-[#1a0c10]/90',
    cardBorder: 'border-rose-500/15',
    accentGradient: 'from-rose-600 to-amber-500',
    accentText: 'text-rose-400',
    badgeBg: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
    heroGlow: 'from-rose-600/20 via-orange-600/5 to-transparent',
  },
  {
    id: 'light',
    name: 'Clean Light',
    dotColor: '#0284c7',
    bgClass: 'bg-[#f4f6fb]',
    textClass: 'text-slate-900',
    cardBg: 'bg-white/95',
    cardBorder: 'border-slate-200 shadow-sm',
    accentGradient: 'from-sky-600 to-blue-600',
    accentText: 'text-sky-600',
    badgeBg: 'bg-sky-100 text-sky-700 border-sky-200',
    heroGlow: 'from-sky-200/40 via-blue-100/20 to-transparent',
  },
];

export function getSavedTheme(): ThemeId {
  if (typeof window === 'undefined') return 'midnight';
  const saved = localStorage.getItem('nt_theme') as ThemeId;
  return THEMES.some((t) => t.id === saved) ? saved : 'midnight';
}

export function saveTheme(theme: ThemeId) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('nt_theme', theme);
  }
}
